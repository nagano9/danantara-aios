# References for institutional-memory-capture

Add only approved, versioned, authoritative references. Record owner, effective date, classification, and superseded status.
